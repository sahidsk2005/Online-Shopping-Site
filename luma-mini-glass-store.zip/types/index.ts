export type Product = {
  id: string;
  name: string;
  price: number;
  image_url: string;
  buy_url: string;
  created_at?: string;
};